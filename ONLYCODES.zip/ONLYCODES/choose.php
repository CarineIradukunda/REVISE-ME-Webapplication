


<!DOCTYPE html>
<html>
<head>
  <title>Choose</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style type="">
  body{background: var(--color-yellow);
  background-image: linear-gradient(
      80deg,
      rgba(84,82,23, 0.9),
      rgba(84,82,23, 0.9)
    ),
    url(https://www.unicef.org/southafrica/sites/unicef.org.southafrica/files/styles/hero_mobile/public/ZAF-XKP166.jpg?itok=3gwGKlYL);}
</style>
<body>

<div class="container">
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand"><img style="height: 60px; width: 60px" src="../images/lgo.png"> </a>
    </div>
    <ul class="nav navbar-nav">
      
     <li><a class="btn btn-success" href="../login/logout.php">Logout</a> <p></p></li></ul>

</div>
</nav>




 <div class="container" style="padding: 4px; box-shadow:  4px 4px 8px  #14F7B6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrFXWKoCtOZRJAgPQ0Ls4S-33EEoUOASLz4A&usqp=CAU);">
      
      
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">NOTES/LESSONS:</h3> <p></p> <p></p>
  <div class="row">
    <div class="col"  >
  <div class="container">
 
  <div class="btn-group-vertical" >

    <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="NOTES/m1.pdf#toolbar=0" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Physics S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Chemistry S1 SB.pdf">Chemistry</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Biology S1 SB.pdf">Biology</a> <p></p>
   
    <a class="dropdown-item" href="BOOKS/S1/History S1 SB.pdf"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item" href="BOOKS/S1/Entrepreneurship S1 SB.pdf">Entrepreneurship</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/MathsS1.pdf">Geography and Environment</a>
    </div>
  </div> 
  <br>
 

  <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
     Senior 2
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  <br>
  <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 



  </div>
</div>
<br>
    </div>
    
    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

     <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
  <br>

   <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
     Senior 5
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
  <br>
  
   <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 

  </div>
</div>
    </div>
  </div>
</div> 

<br>








   
  <div class="container" style="padding: 4px; box-shadow:  4px 4px 8px  #14F7B6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrFXWKoCtOZRJAgPQ0Ls4S-33EEoUOASLz4A&usqp=CAU);">
      
      
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">TEXT BOOKS:</h3> <p></p> <p></p>
  <div class="row">
    <div class="col"  >
  <div class="container">
 
  <div class="btn-group-vertical" >

    <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="BOOKS/S1/MathsS1.pdf#toolbar=0" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Physics S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Chemistry S1 SB.pdf">Chemistry</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Biology S1 SB.pdf">Biology</a> <p></p>
   
    <a class="dropdown-item" href="BOOKS/S1/History S1 SB.pdf"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item" href="BOOKS/S1/Entrepreneurship S1 SB.pdf">Entrepreneurship</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/MathsS1.pdf">Geography and Environment</a>
    </div>
  </div> 
  <br>
 

  <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
     Senior 2
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  <br>
  <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 



  </div>
</div>
<br>
    </div>
    
    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

     <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
       <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
  <br>

   <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
     Senior 5
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
  <br>
  
   <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 

  </div>
</div>
    </div>
  </div>
</div> 

<br>


 <div class="container" style="padding: 4px; box-shadow:   2px 8px 8px 8px  #6AACF6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKdBx6SFRfth-EQl0eIKVhbv0pVsnNFSEKVA&usqp=CAU);">
    
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">EXERCISES :</h3> <p></p> <p></p>
  <div class="row">
    <div class="col">
  <div class="container">
 
  <div class="btn-group-vertical">  
    <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
     <a class="dropdown-item" href="../action/QUIZ/S1/math/mquiz.php" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>

  <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 2
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
     <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
   
  </div>
</div>
<br>
    </div>
    

    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

    <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
       <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 5
    </button>
    <div class="dropdown-menu">
   <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Advanced Mathematics</a> <p></p>
    <a class="dropdown-item">Subsidiary Mathematics</a><p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a><p></p>
    <a class="dropdown-item">Literature</a><p></p>
    <a class="dropdown-item">Economics</a><p></p>
    <a class="dropdown-item">Computer Science</a>
    </div>
  </div> 
                                      

</div>
<br>
</body>
</html>
