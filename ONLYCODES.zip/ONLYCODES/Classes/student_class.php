
<?php
//student_class.php

//connect to database class
require("../Settings/db_class.php");


//create student class 
class stud_class extends db_connection
{
	
	public function add_student($b, $c, $d, $e){

		//Write the sql
		$sql = "INSERT INTO `student` (`student_name`, `student_pass`,`student_contact`,`user_role`) VALUES('$b', '$c', '$d', '$e')";
		
		//return the executed query
		return $this->db_query($sql);
	}


	


	#create a verify login function

	public function verify_login($sname){

		echo $sname;
		//a query to get all login information based on username
		$sql = "SELECT * FROM `student` WHERE `student_name`='$sname'";

		//execute the query
		return $this->db_query($sql);
	}

}

?>