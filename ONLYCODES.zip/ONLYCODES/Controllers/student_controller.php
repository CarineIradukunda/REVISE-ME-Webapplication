<?php
//connect to the student class
require("../Classes/student_class.php");

//a function to insert a new student
function insert_stud_fxn($b, $c, $d, $e){

	//create an instance of student class
	$newstud_object = new stud_class();
	
	//run the add_student method
	$insertstud = $newstud_object->add_student($b, $c, $d, $e);
    
    //check if the student is inserted
	if ($insertstud) {

		//return query result (boolean)
		return $insertstud;
	}else{
		return false;
	}
} 

//search student function - takes the search term
// function search_stud_fxn($stm){
// 	//Create an array variable
// 	$stud_array = array();

// 	//create an instance of the cust class
// 	$stud_object = new stud_class();

// 	//run the search cust method
// 	$stud_records = $stud_object->search_a_stud($stm);

// 	//check if the method worked
// 	if ($stud_records) {
		
// 		//loop to see if there is more than one result
// 		//fetch one at a time
// 		while ($one_record = $stud_object->db_fetch()) {
			
// 			//Assign each result to the array
// 			$stud_array[] = $one_record;
// 		}
// 	}
// 	//returning the array
// 	return $stud_array;
// }

//view all cust function
// function view_all_stud_fxn(){
// 	//Create an array variable
// 	$stud_array = array();

// 	//create an instance of the cust class
// 	$stud_object = new stud_class();

// 	//run the view all cust method
// 	$stud_records = $stud_object->view_all_stud();

// 	//check if the method worked
// 	if ($stud_records) {
		
// 		//loop to see if there is more than one result
// 		//fetch one at a time
// 		while ($one_record = $stud_object->db_fetch()) {
// 			//Assign each result to the array
// 			$stud_array[] = $one_record;
// 		}
// 	}
// 	//return the array
// 	return $stud_array;
// }

//view one cust function - takes the id
// function view_one_stud_fxn($pin){
// 	//Create an array variable
// 	$stud_array = array();

// 	//create an instance of the cust class
// 	$stud_object = new stud_class();

// 	//run the view one cust method
// 	$stud_record = $stud_object->view_one_stud($pin);

// 	//check if the method worked
// 	if ($stud_record) {
		
// 		//fetch the result
// 		$one_record = $stud_object->db_fetch();
// 		//assign to array
// 		$stud_array[] = $one_record;
// 	}
// 	//return array
// 	return $stud_array;
// }



// function delete_stud_fxn($a){
// 	//create an instance of the  class
// 	$deletestudent = new stud_class();
	
// 	//run the delete one cust method
// 	$deletion = $deleteperson->delete_one_stud($a);

// 	//check if method worked
// 	if ($deletion) {

// 		//return query result
// 		return $deletion;
// 	}else{
// 		//return false
// 		return false;
// 	}
	

// }

function get_login_fxn($sname){
	//Create an array variable
	$login_array = array();

	echo $sname;

	//create an instance of the login class
	$login_object = new stud_class();

	//run the verify login method using the email
	$login_record = $login_object->verify_login($sname);

	//check if the method worked
	if ($login_record) {
		
		//fetch the from the result
		$one_record = $login_object->db_fetch();
		//assign to array
		$login_array[] = $one_record;
	}
	//return array
	return $login_array;
}


?>