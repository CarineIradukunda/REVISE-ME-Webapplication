<!DOCTYPE html>
<html>
<head>
  <title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif; background-color: gray; /* For browsers that do not support gradients */
  background-image: linear-gradient(cyan,gray,cyan,gray); color: white}
form {box-shadow:  4px 4px 8px  #14F7B6; border-radius: 25px}

input[type=text], input[type=password] {
  width: 100%;
  padding: 7px 20px;
  margin: 3px 0;
  display: inline-block;
   border:none;
  /*box-sizing: border-box;*/
  /*border-radius: 3px;*/
  background: #f1f1f1;
}

button {
  /*background-color: #303030;*/
  color: white;
  font-weight: bolder;

  padding: 7px 20px;
  margin: 8px 0;
  border:none;
  cursor: pointer;
  width: 100%;
  background-image: linear-gradient(#303030,#080808);
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  /*background-color: #f44336;*/
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">

    <a class="btn btn-dark btn-md" href="gchoose.php" style="font-weight: bold;">Back</a>
    
    
  </div>
    <ul class="nav navbar-nav">
      <li><a class="navbar-brand" ><img style="height: 70px; width: 60px; margin-right:600px" src="../images/logofin.png"> </a></li>
     </ul>

</div>
</nav>

<br>
    


 <!-- <center><h1>Revise-Me</h1> -->
    <!-- <center><img style="height: 80px; width: 60px" src="../images/logofin.png"></center>
     -->
    <center><p style="font-weight: bold;font-size: 16pt; color: black">Guest must have an account to access the content </p></center>
    <hr>

    <div class="container">
    <div class="row">
      
    
<div class="col-sm">
    <p style="font-weight: bold;font-size: 13pt; color: black">Fill this Form to Login </p>
<!-- <div style="box-shadow:  4px 4px 8px  #14F7B6; background-color: #434747; border-radius: 25px"> -->
<form action="../login/loginproc.php" method="POST" style="background-color: #434747;">
  <div class="container" style="padding: 17px">
    
  <!-- <div class="imgcontainer">
    <img src="avatar.png" alt="Avatar" class="avatar">
  </div> -->

 <!--  <div class="container"> -->
    <label for="uname" style="color: white"><b>Full name</b></label>
    <input type="text" placeholder="Enter Full name" name="sname" required>
<br>
<br>

    <label for="psw" style="color: white"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="spass" id="Input" required>
    <br>
    <input type="checkbox" onclick="myPasss()" style="color: white">Show Password
        <br>
<br>

    <button type="submit" name="ulogin">Login</button>
   <!--  <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label> -->
  <!-- </div> -->

<!--   <div class="container"> -->
    <!-- <button type="button" class="cancelbtn">Cancel</button> -->
    <!-- <span class="psw">Forgot <a href="#">password?</a></span> -->
  <!-- </div> -->
</div>
</form><br>
<script>
  function myPasss() {
  var x = document.getElementById("Input");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<!-- </div> -->
</div>


<div class="col-sm">
    <p style="font-weight: bold;font-size: 12pt; color: black">Fill this Form to Create an Account </p>
<form action="../login/registration_process.php" method="GET" style="background-color: #686868">
  <div class="container" style="padding: 20px">
    

    <label for="name" style="color: white;font-size: 10pt"><b>Full Names</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

<br>
    <label for="contact" style="color: white;font-size: 10pt"><b>Phone Number</b></label>
    <input type="text" placeholder="Enter Phone Number" name="contact" required>


<br>
    <label for="psw" style="color: white;font-size: 10pt"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="myInput"  required>
    <input type="checkbox" onclick="myFunction()" style="color: white;font-size: 10pt">Show Password

<br>
<br>
    <!-- <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required> -->
    
    <!-- <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label> -->
    
    <!-- <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p> -->

   <!--  <div class="clearfix"> -->
      <!-- <button type="button" class="cancelbtn">Cancel</button> -->
      <button type="submit" class="signupbtn" value="Submit" name="Submit">Sign Up</button>
    <!-- </div> -->
  </div>
</form> 
<!-- </div> -->
</div>
</div>
</div>
<script>
  function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</div>

</body>
</html>
