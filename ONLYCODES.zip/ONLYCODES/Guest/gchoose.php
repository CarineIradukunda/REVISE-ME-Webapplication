


<!DOCTYPE html>
<html>
<head>
  <title>Choose</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style type="">
  body{background: var(--color-yellow);
  background-image: linear-gradient(
      80deg,
      rgba(84,82,23, 0.9),
      rgba(84,82,23, 0.9)
    ),
    url(https://www.unicef.org/southafrica/sites/unicef.org.southafrica/files/styles/hero_mobile/public/ZAF-XKP166.jpg?itok=3gwGKlYL);}
</style>
<body>

<div class="container">
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../index.php"><img style="height: 60px; width: 60px" src="../images/lgo.png"> </a>
    </div>
    <ul class="nav navbar-nav">
      
     <li><a class="btn btn-primary" href="../Guest/glogin.php" style="font-weight: bold;">Login|Create Account</a> <p></p></li></ul>

</div>
</nav>


<!-- <a class="btn btn-primary" href="../doc/Maths S1 SB.pdf" >CLICK TO DO EXERCISES</a> <p></p> -->
  <!-- <li><button type="button link" class="btn btn-primary">Back</button> <p></p></li> -->
  <!-- <center><h4 style="font-weight: bold;font-family: serif;font-size: 20pt;padding:50px;color: white"></h4></center> -->



<!-- <div class="container"> -->

        <!-- Trigger the modal with a button -->
        <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Math Book</button> -->
        <!-- Modal -->
      <!--   <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog modal-lg"> -->

                <!-- Modal content-->
   <!--              <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Math Book</h4>
                    </div>
                    <div class="modal-body">

                        <embed src="../doc/Maths S1 SB.pdf" frameborder="0" width="100%" height="400px">

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div> -->






 <div class="container" style="padding: 4px; box-shadow:  4px 4px 8px  #14F7B6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrFXWKoCtOZRJAgPQ0Ls4S-33EEoUOASLz4A&usqp=CAU);">
      
      
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">NOTES/LESSONS:</h3> <p></p> <p></p>
  <div class="row">
    <div class="col"  >
  <div class="container">
 
  <div class="btn-group-vertical" >

    <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../Guest/glogin.php" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../Guest/glogin.php" >Physics</a> <p></p>
    <a class="dropdown-item" href="">Chemistry</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Biology S1 SB.pdf">Biology</a> <p></p>
   
    <a class="dropdown-item" href="BOOKS/S1/History S1 SB.pdf"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item" href="BOOKS/S1/Entrepreneurship S1 SB.pdf">Entrepreneurship</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/MathsS1.pdf">Geography and Environment(notdone)!</a>
    </div>
  </div> 
  <br>
 

  <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
     Senior 2
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../Guest/glogin.php" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  <br>
  <div class="dropdown">
    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 



  </div>
</div>
<br>
    </div>
    
    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

     <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
  <br>

   <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
     Senior 5
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
  <br>
  
   <div class="dropdown">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  </div>
</div>
    </div>
  </div>
</div> 

<br>








   
  <div class="container" style="padding: 4px; box-shadow:  4px 4px 8px  #14F7B6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrFXWKoCtOZRJAgPQ0Ls4S-33EEoUOASLz4A&usqp=CAU);">
      
      
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">TEXT BOOKS:</h3> <p></p> <p></p>
  <div class="row">
    <div class="col"  >
  <div class="container">
 
  <div class="btn-group-vertical" >

    <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../Guest/glogin.php" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Physics S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Chemistry S1 SB.pdf">Chemistry</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/Biology S1 SB.pdf">Biology</a> <p></p>
   
    <a class="dropdown-item" href="BOOKS/S1/History S1 SB.pdf"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item" href="BOOKS/S1/Entrepreneurship S1 SB.pdf">Entrepreneurship</a> <p></p>
    <a class="dropdown-item" href="BOOKS/S1/MathsS1.pdf">Geography and Environment(notdone)!</a>
    </div>
  </div> 
  <br>
 

  <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
     Senior 2
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  <br>
  <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S2 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 



  </div>
</div>
<br>
    </div>
    
    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

     <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
  <br>

   <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
     Senior 5
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
  <br>
  
   <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 

  </div>
</div>
    </div>
  </div>
</div> 

<br>


 <div class="container" style="padding: 4px; box-shadow:   2px 8px 8px 8px  #6AACF6; border-radius: 25px;     
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKdBx6SFRfth-EQl0eIKVhbv0pVsnNFSEKVA&usqp=CAU);">
    
    <h3 style=" font-size: 15pt; color: white;font-weight: bold;padding: 10px">EXERCISES :</h3> <p></p> <p></p>
  <div class="row">
    <div class="col">
  <div class="container">
 
  <div class="btn-group-vertical">  
    <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 1
    </button>
    <div class="dropdown-menu">
     <a class="dropdown-item" href="../Guest/glogin.php" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>

  <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 2
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
      Senior 3
    </button>
    <div class="dropdown-menu">
     <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
    <!-- <button type="button link" class="btn btn-warning">Senior 4: Physics</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: History </button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: English</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Subsidiary Mathematics</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Computer Science</button> <p></p>

<button type="button link" class="btn btn-warning">Senior 4: Economics</button> <p></p>

    <button type="button link" class="btn btn-warning">Senior 4: Advabced Mathematics</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: General Studies and communication skills</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Literature </button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Entrepreneurship</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Chemistry</button> <p></p>
     <button type="button link" class="btn btn-warning">Senior 4: Biology</button> <p></p>
    <button type="button link" class="btn btn-warning">Senior 4: Geography and Environment</button> <p></p> -->
  </div>
</div>
<br>
    </div>
    
    <!-- <div class="col-sm">
        <div class="container">
 
  <div class="btn-group-vertical"> -->
        <!-- <button type="button link" class="btn btn-danger">Senior 5: Physics</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: History </button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: English</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Subsidiary Mathematics</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Computer Science</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Economics</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Advanced Mathematics</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: General Studies and communication skills</button><p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Literature </button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Entrepreneurship</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Chemistry</button> <p></p>
     <button type="button link" class="btn btn-danger">Senior 5: Biology</button> <p></p>
    <button type="button link" class="btn btn-danger">Senior 5: Geography and Environment</button> <p></p> -->
 <!--  </div>
</div>
    </div> -->
    <div class="col">
        <div class="container">
 
  <div class="btn-group-vertical">

    <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 4
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 5
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
<br>
  
  <div class="dropdown">
    <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
      Senior 6
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Mathematics</a> <p></p>
    <a class="dropdown-item" href="../doc/Maths S1 SB.pdf" >Physics</a> <p></p>
    <a class="dropdown-item"> History and Citizenship</a> <p></p> 
    <a class="dropdown-item">Home Science</a> <p></p>
    <a class="dropdown-item">Entrepreneurship</a> <p></p>
    <a class="dropdown-item">Chemistry</a> <p></p>
    <a class="dropdown-item">Biology</a> <p></p>
    <a class="dropdown-item">Geography and Environment</a>
    </div>
  </div> 
     <!-- <button type="button link" class="btn btn-dark">Senior 6: Physics</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: History </button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: English</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Subsidiary Mathematics</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Computer Science</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Economics</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Advanced Mathematics</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: General Studies and communication skills</button><p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Literature </button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Entrepreneurship</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Chemistry</button> <p></p>
     <button type="button link" class="btn btn-dark">Senior 6: Biology</button> <p></p>
    <button type="button link" class="btn btn-dark">Senior 6: Geography </button> <p></p> -->
  </div>
</div>
    </div>
  </div>
</div> 
                                      
<!--   <div class="dropdown">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
      Choose Your Year
    </button>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="s1.php">Senior 1</a>
      <a class="dropdown-item" href="s2.php">Senior 2</a>
      <a class="dropdown-item" href="s3.php">Senior 3</a>
      <a class="dropdown-item" href="senior4.php">Senior 4</a>
      <a class="dropdown-item" href="senior5.php">Senior 5</a>
      <a class="dropdown-item" href="senior6.php">Senior 6</a>
    </div>
  </div> -->
</div>
<br>
</body>
</html>
