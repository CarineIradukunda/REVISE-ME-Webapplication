<?php
//for header redirection
ob_start();

//start session

session_start();//session is a way to store information (in variables) to be used across multiple pages.  
session_destroy();  
header("Location:login.php");// redirecting to homepage  


?>