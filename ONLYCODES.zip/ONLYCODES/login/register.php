<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif; background-color: gray; /* For browsers that do not support gradients */
  background-image: linear-gradient(cyan,gray,cyan,gray);}
form {box-shadow:  4px 4px 8px  #14F7B6;background-color: #434747; border-radius: 25px}


  

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 7px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/*input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}*/

/*hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}*/

/* Set a style for all buttons */
button {
 color: white;
  font-weight: bolder;

  padding: 9px 10px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  background-image: linear-gradient(#303030,#080808);

}
.signupbtn{border-radius: 12px}
button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn{
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">

    <a class="btn btn-dark btn-md" href="../index.php" style="font-weight: bold;">Home</a>
    
    
  </div>
    <ul class="nav navbar-nav">
      <li><a class="navbar-brand" ><img style="height: 70px; width: 60px; margin-right:600px" src="../images/logofin.png"> </a></li>
     </ul>

</div>
</nav>
<br>
<!-- <center><h1>Revise-Me</h1>
    <i style='font-size:50px' class='fas'>&#xf5da;</i></center> -->
    <center><p style="font-weight: bold;">Please fill in this form to create an account.</p></center>
    <hr>
    <br>
    <div class="container-fluid" >
<form action="registration_process.php" method="GET">
  <div class="container" style="padding: 5px">
    

    <label for="name" style="color: white"><b>Full Names</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

<br>
    <label for="contact" style="color: white"><b>Phone Number</b></label>
    <input type="text" placeholder="Enter Phone Number" name="contact" required>

<br>
    <label for="psw" style="color: white"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="myInput"  required>
    <input type="checkbox" onclick="myFunction()" style="color: white">Show Password

<br>
    <!-- <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required> -->
    
    <!-- <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label> -->
    
    <!-- <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p> -->

    <div class="clearfix">
      <!-- <button type="button" class="cancelbtn">Cancel</button> -->
      <button type="submit" class="signupbtn" value="Submit" name="Submit">Sign Up</button>
    </div>
  </div>
</form> <br><br>
</div>
<script>
  function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</body>
</html>
