<?php
//for header redirection
ob_start();

//start session - needed to capture login information 
session_start(); 


//connnect to the controller
require("../Controllers/student_controller.php");


//check if login button was clicked 
if (isset($_POST['ulogin'])) {
	
	//get details 
	$sname = $_POST['sname'];
	$spass = $_POST['spass'];
	// echo $sname;

	//check if email exist
	$check_log = get_login_fxn($sname);


	if ($check_log) {
		//email exist, continue to password
		//get password from database
		$hash = $check_log[0]['student_pass'];

		//verify and hash password
		if (password_verify($spass, $hash)) 
		{
				//set session
				$_SESSION["user_id"] = $check_log[0]['student_id'];
				$_SESSION["user_role"] = $check_log[0]['user_role'];
				$_SESSION["user_name"] = $check_log[0]['student_name'];

				if ($_SESSION["user_role"] == 2){
					//redirection to student home page
				header('Location: ../action/choose.php');
				//to make sure the code below does not execute after redirection
				exit;
				} else{
					//redirection to admin home page/////once created!!!!
				header('Location: ../View/index1.php');
				//to make sure the code below does not execute after redirection
				exit;
				}

				
		} else 
		{

			echo "<a href='login.php'><button onclick='".'alert("Username or password is incorrect.")'."'>View login Issue</button>";
			
		}

	} else{


		echo "<a href='login.php'><button onclick='".'alert("Username or password is incorrect.")'."'>Login again</button>";
		
	}
}

?>