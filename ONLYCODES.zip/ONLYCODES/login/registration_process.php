<?php
		//connect to the student controller
		require("../Controllers/student_controller.php");

		//check if submit button was clicked
		if (isset($_GET['Submit'])) {
			// get user form data
			$name = $_GET['name'];
			$pass = isset($_GET['pass']) ? $_GET['pass'] : '';
			$contact = $_GET['contact'];
			$userrole = 2;
			$pass= password_hash($pass, PASSWORD_DEFAULT);
			


			//insert new student
			$insert_stud = insert_stud_fxn($name,$pass,$contact,$userrole);

			// check if student login information is correct
			if ($insert_stud) {

                // if correct they are redirected to the login page
				header('Location: ../login/login.php');
				
				
			}else{
				//failure echo
				echo "<div class='alert alert-danger'>
  						<strong>Not registered!</strong>
					 </div>";
				header('Location: ../login/register.php');
			}
			
		}



		
	?>