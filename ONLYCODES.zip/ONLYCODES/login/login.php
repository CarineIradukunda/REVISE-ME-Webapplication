<!DOCTYPE html>
<html>
<head>
  <title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif; background-color: gray; /* For browsers that do not support gradients */
  background-image: linear-gradient(cyan,gray,cyan,gray);}
form {box-shadow:  4px 4px 8px  #14F7B6;background-color: #434747; border-radius: 25px}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
   border:none;
  background: #f1f1f1;
}

button {
  color: white;
  font-weight: bolder;

  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  background-image: linear-gradient(#303030,#080808);
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}


@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">

    <a class="btn btn-dark btn-md" href="../index.php" style="font-weight: bold;">Home</a>
    
    
  </div>
    <ul class="nav navbar-nav">
      <li><a class="navbar-brand" ><img style="height: 70px; width: 60px; margin-right:600px" src="../images/logofin.png"> </a></li>
     </ul>

</div>
</nav>

<br>
    <br>


    <center><p style="font-weight: bold;font-size: 16pt">Please fill in this form to Log-in </p></center>
    <hr>
    <div class="container-fluid">


<!-- getting data to the loginproc.php file -->
<form action="loginproc.php" method="POST">


  <div class="container">
    <label for="uname" style="color: white"><b>Full name</b></label>
    <input type="text" placeholder="Enter Full name" name="sname" required>
<br>
<br>

    <label for="psw" style="color: white"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="spass" id="myInput" required>
    <br>
    <input type="checkbox" onclick="myFunction()" style="color: white">Show Password
        <br>
<br>

    <button type="submit" name="ulogin">Login</button>

  </div>

</form>

<br>

<!-- the javascript is for hiding or showing the passowrd in the form -->
<script>
  function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</div>

</body>
</html>
