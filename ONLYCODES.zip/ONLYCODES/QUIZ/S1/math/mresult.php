<!DOCTYPE html>
<!--code by webdevtrick (webdevtrick.com) -->
<html>

<head>
    <meta charset="UTF-8" />
    
    <title>Math S1 results</title>
        <!-- <link rel="stylesheet" type="text/css" href="style.css" /> -->
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style type="">
    body {font-family: Arial, Helvetica, sans-serif ; /* For browsers that do not support gradients */;
        background: var(--color-#89F2A3);
  background-image: linear-gradient(
      80deg,
      rgba(0,255,255, 0.8),
      rgba(0,255,255, 0.8)
    ),
    url(https://blog.edmentum.com/sites/blog.edmentum.com/files/styles/blog_image/public/images/ED-Shutterstock_278800745.jpg?itok=gMMiJ2gz);}
    

    #container{
        
        /*display: inline-flex;*/
        font-size: 15pt;
       /* background-color: gray;
        border-radius: 12px;*/
        color: white;  
        width: 60%;
        padding: 4px;box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #434747; border-radius: 25px;

    }





    .btn{
        color: white;
        font-size: 16pt;
        /*font-weight: bold;*/
        font-weight: bold;
        /*padding: 20px;*/
        margin : 20px;
        height: 50px;
        box-shadow:  2px 8px 8px 8px  #6AACF6
    }
</style>
    
    <!-- <link rel="stylesheet" type="text/css" href="style.css" /> -->
</head>

<body>


    <a class='btn btn-dark' href='mquiz.php'>Return to Quiz </a>

    <div id="page-wrap">

        <!-- <h1>Result | Webdevtrick.com</h1> -->
        
        <?php
            $ans1 = "1. the correct answer to question 1 is C because: <br> Number of subsets (Ns ) = 64<br>
NS = 2n,
64 = 2n,
26 = 2n,
n = 6
";
            $ans2 = "2. the correct answer to question 2 is A:  <br>

            The subsets of set B are {}, {a},{b}, {c}, {a,b},{a, c}, {b, c} and {a, b, c}";



            $ans3 = "3. the correct answer to question 3 is B: <br> (a) 3x – 4 ≥ 5  
     ⇒ 3x – 4 + 4 ≥ 5 + 4  <br>
     ⇒ 3x ≥ 9   <br>
     ⇒ 3x/3 ≥ 9/3     (Dividing both sides by 3)  <br>
     ⇒ x ≥ 3  <br>
(b) 1/4 x + 5 ≤ 14<br>
⇒ 1/4 x + 5 – 5 ≤ 14 – 5 ⇒ 1/4 x ≤ 9 <br>
⇒ 1/4 x × 4 ≤ 9 × 4         ⇒ x ≤ 36
";



            $ans4 = "4. the correct answer to question 4 is A:<br>

            Let the number be x. Adding 55 and dividing the sum by 3 gives <br>
    (x + 55)/3= 4x   <br>
             ∴ x + 55 = 12x   <br>
                      55 = 12x – x  <br>
                      55 = 11x   <br>
                        x = 5  <br>
Thus, the number is 5
 
            ";


            $answer1 = $_POST['question-1-answers'];
            $answer2 = $_POST['question-2-answers'];
            $answer3 = $_POST['question-3-answers'];
            $answer4 = $_POST['question-4-answers'];
            // $answer5 = $_POST['question-5-answers'];
        
            $totalCorrect = 0;

            echo "<center><div id='container'> ";
            
            if ($answer1 == "C") {
             $totalCorrect++; 

            }

            else{
                echo " $ans1 <br> <br> ";
            }

            if ($answer2 == "A") {
                $totalCorrect++;
                 }
            else{
                echo "$ans2 <br> <br>";
            }


            if ($answer3 == "B") { $totalCorrect++; }
            else{
                echo "$ans3 <br> <br>";
            }


            if ($answer4 == "A") { $totalCorrect++; }
            else{
                echo "$ans4 <br> <br> ";
            }

            echo "</div></center> <br> <br>";
            // if ($answer5 == "D") { $totalCorrect++; }

            // if ($ans1 
            
            
            // echo "<a href ='mquiz.php'> </a>";
            echo "<center><div class='btn btn-dark'> Your score is $totalCorrect / 4 </div></center> <br>";


            // echo "";


            // echo "correct answers are :<br> 1.C <br> 2.A<br>3.B<br>4.A </div></center><br> ";

            

            
        ?>
    
    </div>

</body>

</html>

