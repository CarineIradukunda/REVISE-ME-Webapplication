<!DOCTYPE html>
<!--code by webdevtrick (webdevtrick.com) -->
<head>
  <meta charset="UTF-8" />
  
  <title>MATH S1 QUIZ</title>
  
  <!-- <link rel="stylesheet" type="text/css" href="style.css" /> -->
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style type="">
    body {font-family: Arial, Helvetica, sans-serif;  /* For browsers that do not support gradients */
  font-size: 8pt;
  background: var(--color-#434747);
  background-image: linear-gradient(
      80deg,
      rgba(128,128,128, 0.9),
      rgba(128,128,128, 0.9)
    ),
    url(https://www.esleschool.com/wp-content/uploads/2019/11/A2-Education-293x300.png);}
  

  button {
  justify-content: center;
  background-color: #303030;
  color: white;
  font-weight: bolder;
  padding:  8px 10px;
  margin: 8px 8px;
  border-radius: 10px;
  cursor: pointer;
  width: 100%;
  /*background-image: linear-gradient(#303030,#080808);*/
}

button:hover {
  opacity: 0.8;
}

@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }



</style>

<body>

    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">

    <a class="btn btn-dark btn-md" href="../../../choose.php" style="font-weight: bold;">Back</a>
    
    
  </div>
    <ul class="nav navbar-nav">
      <li><a class="navbar-brand" ><img style="height: 70px; width: 60px; margin-right:600px" src="lgo.png"> </a></li>
     </ul>

</div>
</nav>

  <!-- <div id="page-wrap"> -->

<center><h4 style="font-weight: bold;font-family: 'Verdana', Sans-serif">MATHEMATICS:Senior 1</h4></center>
<center><h5 style="font-weight: bold;font-family: 'Verdana', Sans-serif"><u> QUIZ</u></h5></center>

        <br>
    
    <form action="mresult.php" method="post" id="quiz">
             <ol style="font-weight: bold;font-size: 16pt">

            <div class="container" style=" box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #89F2A3; border-radius: 25px;padding: 9px; font-size: 11pt"> 
    
           
            
                <li>
                
                    <p>A certain set has 64 subsets. How many elements are there in the set?</p>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-A" value="A" />
                        <label for="question-1-answers-A">A) there are 5 elements. </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B">B) there are 8 elements.</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) there are 6 elements.</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-D" value="D" />
                        <label for="question-1-answers-D">D) there are 12 elements.</label>
                    </div>
                
                </li>

                </div>
<br>


                <div class="container" style=" box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #89F2A3; border-radius: 25px;padding: 10px; font-size: 12pt">
                
                <li>
                
                    <p>Given set B = {a, b, c}, list elements in set B.</p>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-A" value="A" />
                        <label for="question-2-answers-A">A)The subsets of set B are {}, {a},{b}, {c}, {a,b},{a,c}, {b, c} and {a, b, c}.</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-B" value="B" />
                        <label for="question-2-answers-B">B) The subsets of set B are {}, {a},{b}, {b}, {a,b},{a, c}, {b, c} and {a, b, c}</label>
                    </div>


                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-C" value="C" />
                        <label for="question-2-answers-C">C) The subsets of set B are {}, {a},{b}, {a,c}, {a,b},{a, c}, {b, c} and {a, b, c}</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-D" value="D" />
                        <label for="question-2-answers-D">D) None of the above</label>
                    </div>
                
                </li>

            </div>


    <br>

            <div class="container" style=" box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #89F2A3; border-radius: 25px;padding: 10px; font-size: 12pt">
                
                <li>
                
                    <p>What is the answer these following inequalities?: 3x – 4 ≥ 5 and 1/4x + 5 ≤ 14 </p>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-A" value="A" />
                        <label for="question-3-answers-A">A)x ≥ 2 and x ≤ 36</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-B" value="B" />
                        <label for="question-3-answers-B">B) x ≥ 3 and x ≤ 36</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-C" value="C" />
                        <label for="question-3-answers-C">C) x ≥ 2 and x ≤ 33</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-D" value="D" />
                        <label for="question-3-answers-D">D) None Of the Above</label>
                    </div>
                
                </li>
            </div>

            <br>

            <div class="container" style=" box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #89F2A3; border-radius: 25px;padding: 10px; font-size: 12pt">
                
                <li>
                
                    <p>When 55 is added to a certain number and the sum is divided by 3, the result is 4 times the original number. What is the original number?</p>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-4-answers-A" value="A" />
                        <label for="question-4-answers-A">A) the number is 5</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-4-answers-B" value="B" />
                        <label for="question-4-answers-B">B) the number is 13</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-4-answers-C" value="C" />
                        <label for="question-4-answers-C">C) the number is 3</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-4-answers-D" value="D" />
                        <label for="question-4-answers-D">D) none of the above</label>
                    </div>
                
                </li>
</div>
                
        <br>        
            
            </ol>
            <div class="fluid-container" style="display: flex; box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #89F2A3; border-radius: 25px;font-size: 13pt"> 
                <button type="submit" value="Submit" class="submitbtn">Submit</button>
                
            <!-- <input type="submit" value="Submit" class="submitbtn" /> -->
            </div>
    
    </form>
  <br><br>
  <!-- </div> -->


</body>

</html>