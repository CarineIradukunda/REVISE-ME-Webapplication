<!DOCTYPE html>
<html>
<head>
  <title>Revise-Me</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style type="">
  body{background: var(--color-yellow);
  background-image: linear-gradient(
      115deg,
      rgba(80, 100, 100, 0.9),
      rgba(80, 100, 100, 0.9)
    ),
    url(https://www.androidpolice.com/wp-content/themes/ap2/ap_resize/ap_resize.php?src=https%3A%2F%2Fwww.androidpolice.com%2Fwp-content%2Fuploads%2F2020%2F03%2Fe-learning-apps-hero-scaled.jpg&w=728);}
</style>
<body>

<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand"><img style="height: 70px; width: 60px" src="images/lgo.png"> </a>

    </div>
   </div>
</nav>
 
 <div style="box-shadow:  4px 4px 8px  #14F7B6; background-color: #434747; border-radius: 25px">

  <center><h2 class="col" style="font-weight: bold;font-family: serif;padding:6px;font-size: 25pt;color: white">WELCOME TO REVISE-ME</h2><br>
  <p style=" font-size: 14pt; color: white; font-family: sans-serif;">REVISE-ME is an e-learning system that helps Rwandan high school students to revise online by navigating through the content and assessing themselves.</p>
  <p style=" font-size: 14pt; color: white;font-family: sans-serif;">Our content follows the Rwanda Education Board curriculum.</p> <br>

  <a class="btn btn-danger" style="color: white;font-weight: bold;" href="manual.pdf#toolbar=0">Read The Manual Guide</a>
  </center>
  <br>
 </div>
 <br>
 
   <div class="container" style="display: inline-grid; box-shadow:  2px 8px 8px 8px  #6AACF6; background-color: #434747; border-radius: 25px"> 
   	<div class="row">
   		<div class="col-sm">
   			<div class="btn-group-vertical">
   				<p style="color: white; font-size: 15pt">Do you have an Account?</p>
       <a class="btn btn-success" style="color: white;font-weight: bold;" href="login/login.php">Click Here to Login in to your account </a>

    <br> 

       <p style="color: white;font-size: 15pt"> If you do not have an account</p> 
       <a class="btn btn-primary" style="color: white;font-weight: bold;" href="login/register.php">Click Here to Create an account </a>
   
    <br>
</div>
</div>
<br>
<div class="col-sm" style="margin-top: 50px">
   		<div class="btn-group-vertical">
     <p style="color: white; font-size: 15pt">Enter as Guest</p>
     <a class="btn btn-warning" style="color: black;font-weight: bold;" href="Guest/gchoose.php">Click Here to Enter as Guest</a>
 
<br>
  
</div>
   </div> 
  </div>
</div>
</body>
</html>
