<?php
//Database credentials
define("DATABASE", "revise-me");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>





